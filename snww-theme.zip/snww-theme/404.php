<?php get_header(); ?>

<div class="cover not-found-bg">
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-8 center">
            <h1 class="page-title ">Not Found? 🤔</h1>
            <p class="page-info">So... this is awkward</p>
        </div>
      </div>
    </div>
</div>

<main>
  <div class="row">
    <div class="columns content">
      <h2><?php _e( 'Hmm, well I guess it is not here.'); ?></h2>
		  <p><a href="<?php echo get_option('home'); ?>">Let's go home</p>
    </div>
  </div>
</main>

<?php get_footer(); ?>