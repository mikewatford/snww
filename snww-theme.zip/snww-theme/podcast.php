<?php
/*
Template Name: Podcast
*/
?>


<?php get_header(); ?>

<div class="cover podcast-bg">
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-8 center">
            <p class="post-cat center">Podcast</p>
            <h1 class="page-title ">We're the worst</h1>
            <p class="page-info">Nerds discussing and share the best and the worst of dating, beer, food, race, and sexy time.</p>
        </div>
      </div>
    </div>
</div>

<div class="row spacer">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<?php the_content(' '); ?>
</div>

<?php endwhile; ?>
<?php else : ?>

<?php get_template_part( 'inc/post-none' ); ?>

<?php endif; ?>

<?php get_footer(); ?>