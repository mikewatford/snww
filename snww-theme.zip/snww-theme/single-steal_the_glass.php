<?php get_header(); ?>

	<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
    
    <div class="cover" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-10 center">
            <div class="post-cat center"><?php the_category(', '); ?></div>
            <h1 class="page-title "><?php the_title(); ?></h1>
            <h3 class="brewery">Brewed by <span class="capitalize"><?php the_field('brewery_name'); ?></span></h3>
        </div>
      </div>
    </div>
</div>

<main>
    <div class="row">
        <div class="columns content">
          <div class="line-gradient"></div>
          <p><span class="by by-line">Written by <a class="author" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a></span><span class="by"><?php the_time( 'F jS Y' ); ?></span></p>
          <?php the_content(' '); ?>

          <div class="outter-border">
                <div class="row border-bottom">
                    <div class="columns small-12 review-title">The Review</div>
                </div>
                        
                <div class="row">
                    <div class="columns small-4 badge-area border-right"><img src="<?php bloginfo('template_url'); ?>/images/cheers.png"></div>
                    <div class="columns small-6 badge-area beer-content beer-type"><?php the_field('beer_style'); ?></div>
                </div>
    
                <div class="row border-top">
                    <div class="columns small-8 badge-area beer-content"><span class="abv-heading">ABV:</span> <?php the_field('abv'); ?>%</div>
                    <div class="columns small-3 border-left badge-area"><span class="stars-container stars-<?php echo get_field('rating'); ?>">★★★★★</span></div>
                </div>
    
                <div class="row border-top review-content">
                    <div class="columns small-6 border-right badge-area">
                        <h2 class="revew-heading">Tasting Notes</h2>
                        <p><?php the_field('tasting_notes'); ?></p>
                    </div>
                    <div class="columns small-6 badge-area">
                        <h2 class="revew-heading">Would I like it?</h2>
                        <p><?php the_field('would_i_like_it'); ?></p>
                    </div>
                </div>
            </div><!-- beer review -->


        </div>
    </div><!-- row -->
</main>

<?php endwhile; ?>

<?php else : ?>

<?php get_template_part( 'inc/post-none' ); ?>

<?php endif; ?>

<div class="colums small-8 center">
    <div id="disqus_thread"></div>
    <script>
        var disqus_config = function () {
            this.page.url = '<?php echo get_permalink(); ?>';  
            
            this.page.identifier = '<?php echo get_permalink(); ?>'; 
        };
        
        (function() { 
            var d = document, s = d.createElement('script');
            
            s.src = 'https://snww.disqus.com/embed.js';
            
            s.setAttribute('data-timestamp', +new Date());
            (d.head || d.body).appendChild(s);
        })();
    </script>
    <noscript>
        Please enable JavaScript to view the 
        <a href="https://disqus.com/?ref_noscript" rel="nofollow">
            comments powered by Disqus.
        </a>
    </noscript>
</div>

<?php get_footer(); ?>