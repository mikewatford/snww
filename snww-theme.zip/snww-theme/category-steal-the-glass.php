<?php
/*
Template Name: Category Steal the Glass
*/

$args = array(  
    'post_type' => 'steal_the_glass',
    'post_status' => 'publish',
    'posts_per_page' => -1, 
    'order' => 'date',
);

   $loop = new WP_Query( $args );

?>

<?php get_header(); ?>

<div class="cover category-stg">
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-8 center">
            <h1 class="page-title ">Steal the Glass</h1>
            <p class="page-info">We don't buy glasses. We buy beer. We steal glasses.</p>
        </div>
      </div>
    </div>
</div>

<div class="row expanded">

    <?php if ( $loop->have_posts() ) : ?>
    <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

    <div class="small-12 thumb-cover overlay" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
      <a href="<?php the_permalink(); ?>">
        <div class="row align-center">
            <div class="small-12">
                <div class="inner">
                <div class="cat center"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
                    <h2 class="thumb-title"><?php the_title(); ?></h2>
                </div>
            </div>       
        </div>
      </a>
    </div>

    <?php endwhile; ?>

	<?php else : ?>

	<?php get_template_part( 'inc/posts-none' ); ?>

	<?php endif; ?>

</div>

<?php get_footer(); ?>