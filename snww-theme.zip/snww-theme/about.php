<?php get_header(); ?>

    <div class="cover about-bg">
        <div class="tint">
            <div class="row title-position">
                <div class="columns small-6 center">
                    <h1 class="page-title "><?php the_title(); ?></h1>
                    <p class="page-info">Let's get to know each other</p>
                </div>
            </div>
        </div>
    </div>

    <main class="about-content">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php the_content(' '); ?>
	</main>

    <?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/post-none' ); ?>

	<?php endif; ?>

<?php get_footer(); ?>