<?php
/*
Template Name: About
*/
?>

<?php get_header(); ?>

<div class="cover about-bg">
    <div class="about-tint">
      <div class="row about-position">
        <div class="columns small-8 center about-center about fadeIn">
          <h1 class="about-title">About</h1>  
          <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		  <?php the_content(' '); ?>
        </div>
      </div>
    </div>
</div>

<?php endwhile; ?>
<?php else : ?>

<?php get_template_part( 'inc/post-none' ); ?>

<?php endif; ?>

<?php get_footer(); ?>