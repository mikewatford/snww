<footer>
  <div class="row">
    <div class="small-12 social">
      <a href="https://www.instagram.com/supernerdandwonderwoman/"><img src="http://images.supernerdandwonderwoman.com/images/ig.png"></a>
      <a href="https://twitter.com/sprnerdwdrwoman"><img src="http://images.supernerdandwonderwoman.com/images/tw.png"></a>
      <a href="https://www.facebook.com/supernerdandwonderwoman/"><img src="http://images.supernerdandwonderwoman.com/images/fb.png"></a>
      <div class="copyright">Super Nerd &amp; Wonder Woman &copy <?php echo date('Y'); ?> <br><br>#supernerdandwonderwoman</div>
    </div>
  </div>
</footer>

    <script src="<?php bloginfo('template_url'); ?>/js/vendor/jquery.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/vendor/what-input.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/vendor/foundation.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/app.js"></script>
</body>
</html>