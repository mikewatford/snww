<?php get_header(); ?>

	<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
    
    <div class="cover" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-10 center">
            <div class="post-cat center"><?php the_category(', '); ?></div>
            <h1 class="page-title "><?php the_title(); ?></h1>
        </div>
      </div>
    </div>
</div>

<main>
    <div class="row">
        <div class="columns content">
          <div class="line-gradient"></div>
          <p><span class="by by-line">Written by <a class="author" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a></span><span class="by"><?php the_time( 'F jS Y' ); ?></span></p>
          <?php the_content(' '); ?>      
        </div>
    </div><!-- row -->
</main>

<?php endwhile; ?>
<?php else : ?>

<?php get_template_part( 'inc/post-none' ); ?>

<?php endif; ?>

<div class="router">
  
<?php
	$previous = get_previous_post();
	$next = get_next_post();
?>

<?php if ($previous != NULL) { ?>

  <div class="columns small-12 large-expand next-previous" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($previous->ID) ); echo 'style="background-image: url('. $url.');">' ?>
      <div class="shade"></div>
        <div class="hover">
        <a href="<?php echo get_permalink($previous->ID); ?>">
              <div class="previous">Previous Post</div>
              <div class="previous-router-title"><?php echo esc_attr($previous->post_title); ?></div>
          </a>
        </div>
    </div>
    
    <?php } else { ?>

    <div class="columns small-12 large-expand next-previous empty-begin">
      <div class="shade"></div>
        <div class="hover">
              <div class="previous">First things first</div>
              <div class="previous-router-title">Take it from the top</div>
        </div>
    </div>    

    <?php } ?>

    <?php if ($next != NULL) { ?>

    <div class="columns small-12 large-expand next-previous" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($next->ID) ); echo 'style="background-image: url('. $url.');">' ?>
      <div class="shade"></div>
        <div class="hover">
          <a href="<?php echo get_permalink($next->ID); ?>">
              <div class="next">Next Post</div>
              <div class="next-router-title"><?php echo esc_attr($next->post_title); ?></div>
          </a>
        </div>
    </div>

    <?php } else { ?>

    <div class="columns small-12 large-expand next-previous empty-end">
      <div class="shade"></div>
        <div class="hover">
            <div class="next">Last but not least</div>
            <div class="next-router-title">New stuff coming soon</div>
        </div>
    </div>    
    
    <?php } ?>

</div>

<div class="colums small-8 center">
    <div id="disqus_thread"></div>
    <script>
        var disqus_config = function () {
            this.page.url = '<?php echo get_permalink(); ?>';  
            
            this.page.identifier = '<?php echo get_permalink(); ?>'; 
        };
        
        (function() { 
            var d = document, s = d.createElement('script');
            
            s.src = 'https://snww.disqus.com/embed.js';
            
            s.setAttribute('data-timestamp', +new Date());
            (d.head || d.body).appendChild(s);
        })();
    </script>
    <noscript>
        Please enable JavaScript to view the 
        <a href="https://disqus.com/?ref_noscript" rel="nofollow">
            comments powered by Disqus.
        </a>
    </noscript>
</div>

<?php get_footer(); ?>