<?php
/*
Template Name: Home
*/
?>

<?php get_header(); ?>

<div class="cover home-bg">
    <div class="tint">
      <div class="row hero-position">
        <div class="columns small-12 center home-center">
            <img src="<?php bloginfo('template_url'); ?>/images/hero.png" class="slideUp"/>
        </div>
      </div>

      <div class="row tagline-pos">
        <div class="columns small-8 tagline-center">
          <h1 class="tagline">Two geeks walked into a bar<span class="purple">...</span></h1>
        </div>
      </div>

    </div>
</div>

<div class="row expanded">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

    <div class="small-12 thumb-cover overlay" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
      <a href="<?php the_permalink(); ?>">
        <div class="row align-center">
            <div class="small-12 v-center">
              <div class="cat center"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
              <h2 class="thumb-title"><?php the_title(); ?></h2>
            </div>       
        </div>
      </a>
    </div>

  <?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/post-none' ); ?>

	<?php endif; ?>

</div>

  <div class="row">
   <div class="columns large-2 small-6 more-posts-center">
     <div class="more-posts">
       <a href="/journal">More posts</a>
     </div>
   </div>
 </div>

<?php get_footer(); ?>