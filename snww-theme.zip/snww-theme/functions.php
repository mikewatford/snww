<?php
function wpb_remove_version() {

return '';

}
add_filter('the_generator', 'wpb_remove_version');

add_theme_support( 'post-thumbnails' );

remove_filter( 'authenticate', 'wp_authenticate_email_password', 20 );

function no_wordpress_errors(){
  return 'Something is wrong!';
}
add_filter( 'login_errors', 'no_wordpress_errors' );

/*********************
REMOVE QUERY STRING FROM URL
*********************/

function _remove_script_version( $src ){
$parts = explode( '?', $src );
return $parts[0];
}
add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );

add_action( 'pre_get_posts', 'add_custom_post_types_to_loop' );


/*********************
QUERY CPT on home page
*********************/
function add_custom_post_types_to_loop( $query ) {
	if ( is_home() && $query->is_main_query() )
		$query->set( 'post_type', array( 'post', 'steal_the_glass' ) );
	return $query;
}

/*********************
QUERY CPT on Author
*********************/
function author_add_custom_post_types( $query ) {
	if( is_author() && empty( $query->query_vars['suppress_filters'] ) ) {
	  $query->set( 'post_type', array('post', 'steal_the_glass') );
	return $query;
	  }
  }
  add_filter( 'pre_get_posts', 'author_add_custom_post_types' );

/*********************
Pagination
*********************/
function pagination_bar() {
    global $wp_query;
 
    $total_pages = $wp_query->max_num_pages;
 
    if ($total_pages > 1){
        $current_page = max(1, get_query_var('paged'));
 
        echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => '/page/%#%',
            'current' => $current_page,
						'total' => $total_pages,
						'prev_next' => false,
        ));
    }
}

?>