<?php
function wpb_remove_version() {

return '';

}
add_filter('the_generator', 'wpb_remove_version');

add_theme_support( 'post-thumbnails' );

remove_filter( 'authenticate', 'wp_authenticate_email_password', 20 );

function no_wordpress_errors(){
  return 'Something is wrong!';
}
add_filter( 'login_errors', 'no_wordpress_errors' );

/*********************
REMOVE QUERY STRING FROM URL
*********************/

function _remove_script_version( $src ){
$parts = explode( '?', $src );
return $parts[0];
}
add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );

add_action( 'pre_get_posts', 'add_custom_post_types_to_loop' );


/*********************
QUERY CPT on home page
*********************/
function add_custom_post_types_to_loop( $query ) {
	if ( is_home() && $query->is_main_query() )
		$query->set( 'post_type', array( 'post', 'steal_the_glass' ) );
	return $query;
}

/*********************
QUERY CPT on Author
*********************/
function author_add_custom_post_types( $query ) {
	if( is_author() && empty( $query->query_vars['suppress_filters'] ) ) {
	  $query->set( 'post_type', array('post', 'steal_the_glass') );
	return $query;
	  }
  }
  add_filter( 'pre_get_posts', 'author_add_custom_post_types' );

/*********************
Pagination
*********************/
function pagination_bar() {
    global $wp_query;
 
    $total_pages = $wp_query->max_num_pages;
 
    if ($total_pages > 1){
        $current_page = max(1, get_query_var('paged'));
 
        echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => '/page/%#%',
            'current' => $current_page,
						'total' => $total_pages,
						'prev_next' => false,
        ));
    }
}


/*
 * Replacement for get_adjacent_post()
 *
 * This supports only the custom post types you identify and does not
 * look at categories anymore. This allows you to go from one custom post type
 * to another which was not possible with the default get_adjacent_post().
 * Orig: wp-includes/link-template.php 
 * 
 * @param string $direction: Can be either 'prev' or 'next'
 * @param multi $post_types: Can be a string or an array of strings
 */
function mod_get_adjacent_post($direction = 'prev', $post_types = 'post') {
  global $post, $wpdb;

  if(empty($post)) return NULL;
  if(!$post_types) return NULL;

  if(is_array($post_types)){
      $txt = '';
      for($i = 0; $i <= count($post_types) - 1; $i++){
          $txt .= "'".$post_types[$i]."'";
          if($i != count($post_types) - 1) $txt .= ', ';
      }
      $post_types = $txt;
  }

  $current_post_date = $post->post_date;

  $join = '';
  $in_same_cat = FALSE;
  $excluded_categories = '';
  $adjacent = $direction == 'prev' ? 'previous' : 'next';
  $op = $direction == 'prev' ? '<' : '>';
  $order = $direction == 'prev' ? 'DESC' : 'ASC';

  $join  = apply_filters( "get_{$adjacent}_post_join", $join, $in_same_cat, $excluded_categories );
  $where = apply_filters( "get_{$adjacent}_post_where", $wpdb->prepare("WHERE p.post_date $op %s AND p.post_type IN({$post_types}) AND p.post_status = 'publish'", $current_post_date), $in_same_cat, $excluded_categories );
  $sort  = apply_filters( "get_{$adjacent}_post_sort", "ORDER BY p.post_date $order LIMIT 1" );

  $query = "SELECT p.* FROM $wpdb->posts AS p $join $where $sort";
  $query_key = 'adjacent_post_' . md5($query);
  $result = wp_cache_get($query_key, 'counts');
  if ( false !== $result )
      return $result;

  $result = $wpdb->get_row("SELECT p.* FROM $wpdb->posts AS p $join $where $sort");
  if ( null === $result )
      $result = '';

  wp_cache_set($query_key, $result, 'counts');
  return $result;
}

?>