<?php /* Posts loop - No Posts Found */ ?>

<div class="small-12">
	<h3>No published posts found</h3>
	<p>Sorry, but you are looking for something that is not here.</p>
	<p><a href="<?php echo get_option('home'); ?>">Return to the homepage</p>
</div>