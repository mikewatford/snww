<?php
/*
Template Name: Journal
*/

$args = array(  
    'post_type' => 'steal_the_glass',
    'post_status' => 'publish',
    'posts_per_page' => -1, 
    'order' => 'date',
);

   $loop = new WP_Query( $args );

?>

<?php get_header(); ?>

<div class="cover journal-bg">
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-8 center">
            <p class="post-cat center">Journal</p>
            <h1 class="page-title ">Thoughts &amp; Notes</h1>
            <p class="page-info">Collection of our babblings and ramblings</p>
        </div>
      </div>
    </div>
</div>

<div class="row expanded">

    <?php $wpb_all_query = new WP_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>-1)); ?>
	<?php if ( $wpb_all_query->have_posts() ) : ?>
    <?php while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); ?>
    
    <div class="small-6 thumb-cover overlay" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
      <a href="<?php the_permalink(); ?>">
        <div class="row align-center">
            <div class="small-12 v-center">
              <div class="cat center"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
              <h2 class="thumb-title"><?php the_title(); ?></h2>
            </div>       
        </div>
      </a>
    </div>

    <?php endwhile; ?>
    <?php endif; ?>

    <?php if ( $loop->have_posts() ) : ?>
    <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

    <div class="small-6 thumb-cover overlay" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
      <a href="<?php the_permalink(); ?>">
        <div class="row align-center">
            <div class="small-12 v-center">
              <div class="cat center"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
              <h2 class="thumb-title"><?php the_title(); ?></h2>
            </div>       
        </div>
      </a>
    </div>

    <?php endwhile; ?>
    
    <?php wp_reset_postdata(); ?>

    <?php else : ?>

    <?php get_template_part( 'inc/post-none' ); ?>

    <?php endif; ?>

</div>

<?php get_footer(); ?>