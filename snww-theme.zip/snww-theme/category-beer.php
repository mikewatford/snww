<?php
/*
Template Name: Category Beer
*/
?>

<?php get_header(); ?>

<div class="cover category-beer">
    <div class="tint">
      <div class="row title-position">
        <div class="columns small-8 center">
            <?php if ( have_posts() ) : ?>
            <h1 class="page-title ">Beer</h1>
            <p class="page-info">It's the beverage of life</p>
        </div>
      </div>
    </div>
</div>

<div class="row expanded">
<?php while ( have_posts() ) : the_post(); ?>

    <div class="small-12 thumb-cover overlay" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
      <a href="<?php the_permalink(); ?>">
        <div class="row align-center">
            <div class="small-12 v-center">
              <div class="cat center"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
              <h2 class="thumb-title"><?php the_title(); ?></h2>
            </div>       
        </div>
      </a>
    </div>

    <?php endwhile; ?>

	<?php else : ?>

	<?php get_template_part( 'inc/posts-none' ); ?>

	<?php endif; ?>

</div>

<?php get_footer(); ?>