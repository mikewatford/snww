<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="Description" content="The Chrissy Teigen and John Legend of Nerds discuss and share the best and the worst of dating, beer, food, race, and sexy time." />
  <meta name="author" content="Mike Watford">
  <meta property="og:title" content="Super Nerd and Wonder Woman" />
  <meta property="og:description" content="The Chrissy Teigen and John Legend of Nerds discuss and share the best and the worst of dating, beer, food, race, and sexy time." />
  <meta property="og:url" content="https://www.supernerdandwonderwoman.com/" />
  <meta property="og:image" content="https://www.supernerdandwonderwoman.com/images/og.png" />
  <meta property="og:locale" content="en_US">
  <meta property="og:site_name" content="Super Nerd and Wonder Woman" />
  <meta property="og:type" content="website" />
  <meta name="twitter:site" content="@sprnerdwdrwoman" />
  <meta name="twitter:card" content="summary_large_image" />
  
  <title><?php wp_title(''); ?><?php if(wp_title(' ', false)) { echo ' | '; } ?><?php bloginfo('name'); ?></title>
  
  <link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon"/>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/foundation.min.css" />
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/main.css">
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/wickedcss.min.css">
  <link rel="dns-prefetch" href="//fonts.googleapis.com">
  <?php wp_head(); ?>
</head>

<body>

<!-- mobile nav bar -->
<div class="title-bar topbar-center-logo-mobile" data-responsive-toggle="topbar-center-logo" data-hide-for="medium">
  <div class="title-bar-left">
    <div class="title-bar-title"><a href="/home"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" width="100" height="39" alt="" /></a></div>
  </div>
  <div class="title-bar-right">
    <button class="menu-icon" type="button" data-toggle="topbar-center-logo"></button>
  </div>
</div>
<!-- /mobile nav bar -->

<!-- medium and larger nav bar -->
<div class="top-bar topbar-center-logo" id="topbar-center-logo">
  <div class="top-bar-left">
    <ul class="menu vertical medium-horizontal">
      <li><a href="/journal/">Journal</a></li>
      <li><a href="/travel/">Travel</a></li>
      <li class="gap"><!-- <a href="/podcast/">Podcast</a> --></li>
    </ul>
  </div>
  <div class="top-bar-center">
    <a href="/home"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" width="100" height="39" alt="" /></a>
  </div>
  <div class="top-bar-right">
    <ul class="menu vertical medium-horizontal">
      <li><a href="/about/">About</a></li>
      <li><a href="https://www.instagram.com/supernerdandwonderwoman/">Instagram</a></li>
      <li><a href="https://twitter.com/sprnerdwdrwoman">Twitter</a></li>
    </ul>
  </div>
</div>
<!-- /medium and larger nav bar -->