<?php
/*
*
Template Name: Travel
*
*/

$args = array (  
    'post_type' => 'location',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'order' => 'date',
   );

$loop = new WP_Query( $args );

?>

<?php get_header(); ?>

<div class="cover travel-bg">
  <div class="tint">
    <div class="row title-position">
      <div class="columns small-8 center">
        <p class="post-cat center">Travel</p>
        <h1 class="page-title ">Jet setting</h1>
        <p class="page-info">Sometimes we travel and when we do we eat all the things.</p>
      </div>
    </div>
  </div>
</div>

<div class="row">

  <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
   
  <div class="columns small-12">
    <div class="travel-card" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
      <div class="tc-line-gradient"></div>
      <div class="tc-tint">
        <div class="tc-content">
          <span class="break"><?php the_field('state'); ?></span>
          <span class="city"><?php the_field('city'); ?></span>
          <div class="btn"><a href="/category/travel/<?php echo get_field('city'); ?>/">View Posts</a></div>
        </div>
      </div>
    </div>
  </div>

  <?php endwhile; ?>

</div>

<?php wp_reset_postdata(); ?>

<?php get_footer(); ?>