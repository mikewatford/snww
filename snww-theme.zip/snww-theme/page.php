<?php get_header(); ?>

    <div class="cover" <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo 'style="background-image: url('. $url.');"' ?>>
        <div class="tint">
            <div class="row title-position">
                <div class="columns small-6 center">
                    <div class="post-cat center"><?php $category = get_the_category(); echo $category[0]->cat_name;?></div>
                    <h1 class="page-title "><?php the_title(); ?></h1>
                </div>
            </div>
        </div>
    </div>

    <main>
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php the_content(' '); ?>
	</main>

    <?php endwhile; ?>
	<?php else : ?>

	<?php get_template_part( 'inc/post-none' ); ?>

	<?php endif; ?>

<?php get_footer(); ?>